# comp551-p3
due to the size of the sets you need to run my Preprocessor.py to get the validation and training sets respectively.

You should see a the current status of the completion if the script runs well and have 2 files appear where the script is.
