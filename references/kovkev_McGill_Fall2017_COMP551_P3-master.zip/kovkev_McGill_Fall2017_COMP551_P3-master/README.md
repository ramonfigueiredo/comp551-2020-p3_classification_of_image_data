# McGill_Fall2017_COMP551_P3

Dependencies:

 - tensorflow
 - pandas
 - numpy
 - keras

Download all data files in the current directory.

Logistic regression:

```
python logreg.py
```

Feed Forward Neural Network:

```
python ffnn.py
```

Convolutional Neural Network:

```
python cnn.py
```
